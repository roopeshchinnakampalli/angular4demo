import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';

import { Product } from './product';
import { ProductService } from './product.service';



@Component({
  selector: 'my-products',
  templateUrl: './products.component.html'
  
})
export class ProductsComponent implements OnInit  {
  
  products: Product[];
  
  selectedProduct: Product;

  onSelect(product: Product): void {
    this.selectedProduct = product;
  }

constructor(private productService: ProductService,private router: Router) {

}

getProducts(): void {
  this.productService.getProducts().then(products => this.products = products);
}

ngOnInit(): void {
  this.getProducts();
}

gotoDetail(): void {
  this.router.navigate(['/detail', this.selectedProduct.id]);
}

}



